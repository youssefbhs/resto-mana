package testinterface;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JComponent;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class lista extends JFrame {
	static lista frame = new lista();
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public lista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1078, 577);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAddOrder = new JButton("add order");
		btnAddOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addorder addord=new addorder();
				addord.setVisible(true);
				frame.setVisible(false);
				
				
				
			}
		});
		btnAddOrder.setBounds(62, 240, 152, 44);
		contentPane.add(btnAddOrder);
		
		JButton btnAddNewProduct = new JButton("add new product");
		btnAddNewProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Category categ=new Category();
				categ.setVisible(true);
				frame.setVisible(false);
				
				
			}
		});
		btnAddNewProduct.setBounds(292, 240, 188, 44);
		contentPane.add(btnAddNewProduct);
		
		JButton btnRemoveOrder = new JButton("remove order");
		btnRemoveOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addorder addord=new addorder();
				addord.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnRemoveOrder.setBounds(542, 240, 152, 44);
		contentPane.add(btnRemoveOrder);
		
		JButton btnDisplayBill = new JButton("display bill");
		btnDisplayBill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addorder addord=new addorder();
				addord.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnDisplayBill.setBounds(799, 240, 147, 44);
		contentPane.add(btnDisplayBill);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				testit t = new testit();
				t.main(null);
				
				frame.setVisible(false);
				
				
				
				
			}
		});
		btnBack.setBounds(452, 429, 115, 29);
		contentPane.add(btnBack);
	}
	

}
