package testinterface;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;

public class testit {

	private JFrame frame;
	private JTextField textFieldUserName;
	private JPasswordField passwordFieldPassword;
	
    

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					testit window = new testit();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public testit() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 18));
		frame.setBounds(100, 100, 899, 547);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnLogIn = new JButton("log in");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					String usrnmo="1";
					String passo="1";
					String Usrnm=textFieldUserName.getText();
					String Pass=passwordFieldPassword.getText();
					if (Usrnm.equalsIgnoreCase(usrnmo) && Pass.equals(passo)) {
						JOptionPane.showMessageDialog(null,"login successfully!");
						frame.dispose();
						lista listaa= new lista();
						listaa.setVisible(true);
						
						
					}else {
						JOptionPane.showMessageDialog(null, "username or password is not correct please try again");
					}
					
					
					
				} catch (Exception e) {JOptionPane.showMessageDialog(null, "there is an error");
					
				}
				
				
				
				
			}
		});
		btnLogIn.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnLogIn.setBounds(366, 359, 146, 49);
		frame.getContentPane().add(btnLogIn);
		
		textFieldUserName = new JTextField();
		textFieldUserName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldUserName.setBounds(366, 133, 146, 26);
		frame.getContentPane().add(textFieldUserName);
		textFieldUserName.setColumns(10);
		
		passwordFieldPassword = new JPasswordField();
		passwordFieldPassword.setFont(new Font("Tahoma", Font.PLAIN, 18));
		passwordFieldPassword.setBounds(366, 224, 146, 26);
		frame.getContentPane().add(passwordFieldPassword);
		
		JLabel lblUserName = new JLabel("user name");
		lblUserName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUserName.setBounds(259, 135, 92, 23);
		frame.getContentPane().add(lblUserName);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPassword.setBounds(271, 226, 80, 23);
		frame.getContentPane().add(lblPassword);
	}

	
}
