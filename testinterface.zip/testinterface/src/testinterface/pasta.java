package testinterface;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class pasta extends JFrame {

	private JPanel contentPane;
	static pasta frame = new pasta();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pasta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Category g=new Category();
				g.main(null);
				frame.dispose();
				
			}
		});
		btnBack.setBounds(40, 491, 115, 29);
		contentPane.add(btnBack);
		
		JButton btnNewButton = new JButton("lasagnes");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(145, 40, 225, 60);
		contentPane.add(btnNewButton);
		
		JButton btnCannellonis = new JButton("cannellonis");
		btnCannellonis.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCannellonis.setBounds(145, 190, 225, 60);
		contentPane.add(btnCannellonis);
		
		JButton btnPenne = new JButton("pennes");
		btnPenne.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPenne.setBounds(145, 332, 225, 60);
		contentPane.add(btnPenne);
		
		JButton btnSpaghettis = new JButton("Spaghettis");
		btnSpaghettis.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSpaghettis.setBounds(598, 40, 225, 60);
		contentPane.add(btnSpaghettis);
		
		JButton btnTagliatelles = new JButton("Tagliatelles ");
		btnTagliatelles.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnTagliatelles.setBounds(598, 190, 225, 60);
		contentPane.add(btnTagliatelles);
	}

}
