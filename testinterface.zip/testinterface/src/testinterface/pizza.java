package testinterface;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class pizza extends JFrame {

	private JPanel contentPane;
	static pizza frame = new pizza();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pizza() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 960, 591);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Category g=new Category();
				g.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(40, 490, 115, 29);
		contentPane.add(btnBack);
		
		JButton btnPizzaThon = new JButton("pizza thon");
		btnPizzaThon.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPizzaThon.setBounds(104, 83, 236, 65);
		contentPane.add(btnPizzaThon);
		
		JButton btnPizzafromages = new JButton("pizza 4fromages");
		btnPizzafromages.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnPizzafromages.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPizzafromages.setBounds(104, 215, 236, 65);
		contentPane.add(btnPizzafromages);
		
		JButton btnPizzaSaisons = new JButton("pizza 4 saisons");
		btnPizzaSaisons.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPizzaSaisons.setBounds(104, 353, 236, 65);
		contentPane.add(btnPizzaSaisons);
		
		JButton btnPizzaMargeritta = new JButton("pizza margeritta");
		btnPizzaMargeritta.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPizzaMargeritta.setBounds(532, 83, 236, 65);
		contentPane.add(btnPizzaMargeritta);
	}

}
