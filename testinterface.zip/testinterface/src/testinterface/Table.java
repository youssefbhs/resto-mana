package testinterface;

public class Table {

}
