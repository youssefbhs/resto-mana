package testinterface;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Category extends JFrame {

	private JPanel contentPane;
	static Category frame = new Category();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Category() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 992, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnPizza = new JButton("pizza");
		btnPizza.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pizza p=new pizza();
				p.setVisible(true);
				frame.dispose();
			}
		});
		btnPizza.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnPizza.setBounds(89, 127, 115, 29);
		contentPane.add(btnPizza);
		
		JButton btnPasta = new JButton("Pasta");
		btnPasta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pasta pa=new pasta();
				pa.setVisible(true);
				frame.dispose();
				
			}
		});
		btnPasta.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnPasta.setBounds(404, 127, 115, 29);
		contentPane.add(btnPasta);
		
		JButton btnFish = new JButton("Fish");
		btnFish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fish f =new fish();
				f.setVisible(true);
				frame.dispose();
			}
		});
		btnFish.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnFish.setBounds(715, 128, 115, 29);
		contentPane.add(btnFish);
		
		JButton btnDrinks = new JButton("drinks");
		btnDrinks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				drinks d = new drinks();
				d.setVisible(true);
				frame.dispose();
			}
		});
		btnDrinks.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDrinks.setBounds(89, 313, 115, 29);
		contentPane.add(btnDrinks);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addorder ord=new addorder();
				ord.main(null);
				frame.dispose();
				
			}
		});
		btnBack.setBounds(40, 491, 115, 29);
		contentPane.add(btnBack);
	}

}
